#!bin/bash

Test=73
Mod$(( $Test % 8 ))
echo $Mod


x=$(( x=4**6 ))
y=$(( y=5**3 ))
z=$(( x+y ))
echo $z

if [[ $Mod == $ x ]]; Then
	echo "The numbers are the same."
else 
	echo "The numbers are not the same"
fi

 
