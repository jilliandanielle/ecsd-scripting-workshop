#!/bin/bash

if $3<4; then
    echo $3" is less than 4"
fi
