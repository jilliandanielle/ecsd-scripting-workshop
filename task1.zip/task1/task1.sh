#!/bin/bash

newVariable='Hello world!'

specialChar="Using different", 'characters to test!'

echo $newVariable

echo $SHELLOPTS

exit 0
